﻿namespace ElectricalAppliances.Console.TypeGAppliances
{
    public class UKCamera : ITypeGPluggableAppliance
    {
    }
}