﻿namespace ElectricalAppliances.Console.TypeAAppliances
{
    public class HairDryer : ITypeAPluggableAppliance
    {
    }
}