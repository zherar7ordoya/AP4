﻿namespace ElectricalAppliances.Console.TypeAAppliances
{
    public class Computer : ITypeAPluggableAppliance
    {
    }
}