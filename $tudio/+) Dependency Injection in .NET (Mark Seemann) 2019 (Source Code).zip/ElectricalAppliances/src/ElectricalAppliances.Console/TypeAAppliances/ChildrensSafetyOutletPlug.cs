﻿namespace ElectricalAppliances.Console
{
    // Null Object
    public class ChildrensSafetyOutletPlug : ITypeAPluggableAppliance
    {
    }
}