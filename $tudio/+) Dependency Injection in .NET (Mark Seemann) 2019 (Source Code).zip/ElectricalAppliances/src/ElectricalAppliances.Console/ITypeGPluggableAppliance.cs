﻿namespace ElectricalAppliances.Console
{
    // Type G plugs are used in the UK.
    public interface ITypeGPluggableAppliance
    {
    }
}