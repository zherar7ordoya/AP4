﻿namespace ElectricalAppliances.Console
{
    // Type A plugs are used in North America
    public interface ITypeAPluggableAppliance
    {
    }
}