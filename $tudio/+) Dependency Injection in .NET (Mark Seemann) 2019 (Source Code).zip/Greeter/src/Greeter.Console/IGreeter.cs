﻿namespace Ploeh.Samples.Greeter.Console
{
    // ---- Code Section 9.1.1 ----
    public interface IGreeter
    {
        string Greet(string name);
    }
}