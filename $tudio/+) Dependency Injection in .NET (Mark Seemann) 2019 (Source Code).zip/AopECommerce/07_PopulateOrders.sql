INSERT INTO Orders ([Id], [Approved], [Cancelled], [Payed])
VALUES ('c3158ecd-f1c5-4c62-96c8-aabe84bca207', 0, 0, 0);

INSERT INTO Orders ([Id], [Approved], [Cancelled], [Payed])
VALUES ('c1efc8c4-b0ba-483f-b253-4496876786cd', 1, 1, 0);

INSERT INTO Orders ([Id], [Approved], [Cancelled], [Payed])
VALUES ('c69cec49-fdf9-4abf-9809-09334d3840d4', 0, 1, 0);

INSERT INTO Orders ([Id], [Approved], [Cancelled], [Payed])
VALUES ('8ea58011-832a-46f6-93f1-e313d6aa7a93', 1, 0, 1);

