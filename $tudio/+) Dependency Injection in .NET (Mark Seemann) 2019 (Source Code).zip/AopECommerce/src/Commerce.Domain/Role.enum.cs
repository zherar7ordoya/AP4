﻿namespace Ploeh.Samples.Commerce.Domain
{
    // ---- Start code Listing 10.17 ----
    public enum Role
    {
        PreferredCustomer,
        InventoryManager,
        Administrator,
        // ---- End code Listing 10.17 ----

        OrderManager,
    }
}