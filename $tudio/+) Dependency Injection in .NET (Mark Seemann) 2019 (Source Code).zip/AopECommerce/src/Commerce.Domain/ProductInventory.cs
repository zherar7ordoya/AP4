﻿using System;

namespace Ploeh.Samples.Commerce.Domain
{
    public class ProductInventory
    {
        public Guid Id { get; set; }
        public int Quantity { get; set; }
    }
}