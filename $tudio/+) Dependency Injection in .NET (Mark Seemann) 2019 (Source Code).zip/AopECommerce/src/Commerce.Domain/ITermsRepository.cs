﻿namespace Ploeh.Samples.Commerce.Domain
{
    public interface ITermsRepository
    {
        string GetActiveTerms();
    }
}