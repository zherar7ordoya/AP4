INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('a5c6a6fb-90ea-4f7b-a293-7f2b7aea865c', 'Criollo Chocolate', '', 34.9500, 1)

INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('76e1526e-edea-4964-a8be-28c643d77af1', 'Arborio Rice', '', 22.7500, 1)

INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('818667d4-fe4c-47ca-90f0-fb6dcfe14a2a', 'White Asparagus', '', 39.8000, 1)

INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('464dcd20-d5e6-457e-b2f3-142c4e5d9186', 'Maldon Sea Salt', '', 19.5000, 0)

INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('728165b2-4797-47b8-ad59-002ea4263a25', 'Gruy�re', '', 48.5000, 1)

INSERT INTO Products ([Id], [Name], [Description] ,[UnitPrice], [IsFeatured])
VALUES ('3f9056fb-6f12-44cb-bcf8-eff8b75e05d6', 'Anchovies', '', 18.7500, 1)


