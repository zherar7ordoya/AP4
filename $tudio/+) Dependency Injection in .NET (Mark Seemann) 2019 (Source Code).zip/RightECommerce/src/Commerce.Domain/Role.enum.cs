﻿namespace Ploeh.Samples.Commerce.Domain
{
    public enum Role { PreferredCustomer }
}