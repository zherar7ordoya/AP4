﻿namespace Commerce.UpdateCurrency.ApplicationServices
{
    public interface ICommand
    {
        void Execute();
    }
}