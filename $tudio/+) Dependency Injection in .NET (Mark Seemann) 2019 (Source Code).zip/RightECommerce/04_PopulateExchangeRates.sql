-- All rates compared to the US Dollar (per 2018-12-10).
INSERT INTO ExchangeRates ([Id], [CurrencyCode], [Rate]) VALUES (NEWID(), 'USD', 1.00)
INSERT INTO ExchangeRates ([Id], [CurrencyCode], [Rate]) VALUES (NEWID(), 'EUR', 0.88)
INSERT INTO ExchangeRates ([Id], [CurrencyCode], [Rate]) VALUES (NEWID(), 'GBP', 0.79)
INSERT INTO ExchangeRates ([Id], [CurrencyCode], [Rate]) VALUES (NEWID(), 'DKK', 6.54)
INSERT INTO ExchangeRates ([Id], [CurrencyCode], [Rate]) VALUES (NEWID(), 'CAD', 1.33)
