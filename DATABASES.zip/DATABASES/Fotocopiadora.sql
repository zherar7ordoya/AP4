SELECT *
INTO   RJCodeAdvance.dbo.Clientes
FROM   Practica_Patrones.dbo.Clientes