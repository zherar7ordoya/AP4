CREATE PROC VerRegistros @Condicion NVARCHAR(30)
AS
    SELECT *
    FROM   [C:\DOCUMENTS\AP4\DATABASES\RJCODEADVANCE.MDF].dbo.Clientes
    WHERE  id LIKE @Condicion + '%'
            OR nombre LIKE @Condicion + '%'

go

EXEC VerRegistros
  'Romeo' 