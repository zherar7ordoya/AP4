typedef struct {
  double capacity;
  double initialLevel;
  int alarm;
  char name[256];
  } TANK_INFO;
#define TANK_DESCR "FFic[256]"