<html>
<title> mi primera página web</title>
<head></head>
<body> 
<center> 
<table border="1" style="width:90%;">
<tr>
<td colspan="5" style="height:200px; style="text-align:center;">
<h1> <center> GASGA. FLORES. URZUA </h1>
<audio src="audio/EVERY.mp3" controls autoplay="true">
</tr>

<tr> 
<td>
<h1><center>inicio</h1>
</td>
<td>
<h1><center>historia</h1>
</td>
<td>
<h1><center>fotogaleria</h1>
</td>
<td>
<h1><center>videos</h1>
<a href="video.html">
</td>
<td>
<h1><center>contactos</h1>
</tr>

<tr>
<td colspan="2">
<h1><center>submenú de la página</h1>

<td colspan="3">
<h1><center></h1>
<img src="fotos/imagen6.JPG"width="200"
height="200">
<img src="fotos/imagen2.JPG"width="200"
height="200">
<img src="fotos/imagen3.JPG"width="200"
height="200">
<img src="fotos/imagen1.JPG"width="200"
height="200">
<img src="fotos/imagen8.JPG"width="200"
height="200">
<img src="fotos/imagen7.JPG"width="200"
height="200">
</tr>

<tr>
<td colspan="5">
<h1>pie de página</h1>
</tr>
</table>
<body>
</html>
