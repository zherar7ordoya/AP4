function [a,b,c,d] = sscont
a = [0 1;-1 -1];
b = [0;1];
c = [1 0];
d = [0];
