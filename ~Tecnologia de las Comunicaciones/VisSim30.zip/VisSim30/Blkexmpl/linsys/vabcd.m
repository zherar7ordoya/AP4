function [a,b,c,d] = vabcd
a = [0 1;-1 -1];
b = [0;1];
c = [1 1];
d = [0];
