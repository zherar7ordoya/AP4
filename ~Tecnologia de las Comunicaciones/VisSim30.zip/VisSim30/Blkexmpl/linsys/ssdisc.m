function [a,b,c,d] = ssdisc
a = [0 1; -.9 -.2];
b = [0;1];
c = [1 1];
d = [0];
